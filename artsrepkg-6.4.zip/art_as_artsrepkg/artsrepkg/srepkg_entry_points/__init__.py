import artsrepkg.srepkg_entry_points.art

