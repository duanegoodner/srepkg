import howdoisrepkg.srepkg_entry_points.howdoi

