"""
Package that gets included in a repackaged .whl or sdist. When `pip install`
is called with repackaged .whl or sdist as the arg, inner_pakg_installer handles
venv creation and installation of original package in venv.
"""