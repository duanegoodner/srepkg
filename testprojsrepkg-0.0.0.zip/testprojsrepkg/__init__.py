"""
Gets copied as __init__.py into top level of SRE-packaged app to mmke it a
package.
"""
