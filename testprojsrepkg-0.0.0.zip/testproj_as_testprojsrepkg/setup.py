"""
Minimal setup.py file.
"""
import setuptools

setuptools.setup()

