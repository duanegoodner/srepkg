import testprojhyphenentry.app as app


def main():
    app.run()


if __name__ == "__main__":
    main()
