def simple_test():
    print('This is a test')