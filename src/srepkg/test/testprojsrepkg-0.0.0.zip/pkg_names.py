inner_pkg_name = 'testproj'
sre_pkg_name = 'testprojsrepkg'
