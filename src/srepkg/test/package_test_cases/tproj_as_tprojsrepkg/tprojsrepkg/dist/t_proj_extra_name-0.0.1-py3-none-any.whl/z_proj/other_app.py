def run():
    print("This is the main routine for z_proj.")


if __name__ == '__main__':
    run()