import z_proj.other_app as app


def main():
    app.run()


if __name__ == "__main__":
    main()