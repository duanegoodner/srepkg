import z_proj.x_proj.app as app


def main():
    app.run()


if __name__ == "__main__":
    main()