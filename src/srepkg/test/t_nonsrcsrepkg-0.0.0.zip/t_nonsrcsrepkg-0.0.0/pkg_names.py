inner_pkg_name = 't_nonsrc'
sre_pkg_name = 't_nonsrcsrepkg'
