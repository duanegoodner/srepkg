"""
Gets copied as __init__.py into top level of SRE-packaged app to mamke it a
package.
"""