def run():
    print("This is the main routine.")
    print("It should do something interesting.")


if __name__ == '__main__':
    run()